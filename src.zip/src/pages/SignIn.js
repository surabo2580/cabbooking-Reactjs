import React from 'react';
import './signin.css';
import { useState } from 'react';
import axios from 'axios';
  
const SignIn = () => {
    const [email,setEmail] = useState("");
    const [password,setPassword] = useState("");

    const onInputChangeEmail = event => {
        setEmail(event.target.value);
      };
    const onInputChangePassword = event => {
    setPassword(event.target.value);
    };

    const data = {"email":email,"password":password};
    const FormHandle = e => {
        e.preventDefault();
        addDataToServer(data)
    }

    const addDataToServer = (cred) => {
        console.log(cred);
        axios.post("http://localhost:8080/productapi/saveproduct", cred).then(
            (response) => {
                console.log(response);
                alert("product Added Successfully");
            }, (error) => {
                console.log(error);
                alert("Operation failed");
            }
        );
    }

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'Center',
        alignItems: 'Center',
        height: '100vh'
      }}
    >
      
      <div className='signin'>
            <form onSubmit={e => FormHandle(e)} className="check-credentials-form">
                <br></br>
                <div id="email" class="form-group">
                    <input type="text" class="form-control" name="email"  placeholder="Enter email" value={email} onChange={(e) => onInputChangeEmail(e)} />
                </div><br></br>
                <div id="password" class="form-group">
                    <input type="text" class="form-control" name="password"  placeholder="Enter password" value={password} onChange={(e) => onInputChangePassword(e)} />
                </div><br></br>
                
                <div className="btnsignin">
                    <button type="submit" class="btn btn-outline-secondary my-2 text-center mr-2">Sign In</button><br></br>
                    
                </div>
            </form>
        </div>
    </div>
  );
};

export default SignIn;