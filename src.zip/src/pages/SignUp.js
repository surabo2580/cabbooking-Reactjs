import React from 'react';
import { useState } from 'react';
import './signup.css';
import axios from 'axios';
  
const SignUp = () => {
    const[firstname,setFirstName] = useState("");
    const[lastname,setLastName] = useState("");
    const[email,setEmail] = useState("");
    const[phone,setPhone] = useState("");
    const [password,setPassword] = useState("");
    const [confirmpassword,setConfirmPassword] = useState("");

    const onInputChangeFirstName = event => {
        setFirstName(event.target.value);
      };
    const onInputChangeLastName = event => {
    setLastName(event.target.value);
    };
    const onInputChangePhone = event => {
        setPhone(event.target.value);
        };
    const onInputChangeEmail = event => {
        setEmail(event.target.value);
      };
    const onInputChangePassword = event => {
    setPassword(event.target.value);
    };
    const onInputChangeConfirmPassword = event => {
        setConfirmPassword(event.target.value);
        };

    const data = {"firstname":firstname,"lastname":lastname,"email":email,"phone":phone,"password":password,"confirmpassword":confirmpassword};
    const FormHandle = e => {
        e.preventDefault();
        addDataToServer(data)
    }
    console.log(data);
    const addDataToServer = (cred) => {
        console.log(cred);
        axios.post("http://localhost:8080/productapi/saveproduct", cred).then(
            (response) => {
                console.log(response);
                alert("product Added Successfully");
            }, (error) => {
                console.log(error);
                alert("Operation failed");
            }
        );
    }

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'Center',
        alignItems: 'Center',
        height: '100vh'
      }}
    >
      
      <div className='signup'>
            <form onSubmit={e => FormHandle(e)} class="check-credentials-formsp">
                <br></br>
                <div id="firstnamesp" class="firstname">
                    <input type="text" class="form-control" name="firstname"  placeholder="Enter First Name" value={firstname} onChange={(e) => onInputChangeFirstName(e)} />
                </div><br></br>
                <div id="lastnamesp" class="lastname">
                    <input type="text" class="form-control" name="lastname"  placeholder="Enter Last Name" value={lastname} onChange={(e) => onInputChangeLastName(e)} />
                </div><br></br>
                <div id="phonesp" class="phone">
                    <input type="number" class="form-control" name="phone"  placeholder="Enter phone" value={phone} onChange={(e) => onInputChangePhone(e)} />
                </div><br></br>
                <div id="emailsp" class="email">
                    <input type="text" class="form-control" name="email"  placeholder="Enter email" value={email} onChange={(e) => onInputChangeEmail(e)} />
                </div><br></br>
                <div id="passwordsp" class="password">
                    <input type="text" class="form-control" name="password"  placeholder="Enter password" value={password} onChange={(e) => onInputChangePassword(e)} />
                </div><br></br>
                <div id="confirmpasswordsp" class="confirmpassword">
                    <input type="text" class="form-control" name="confirmpassword"  placeholder="Re Enter password" value={confirmpassword} onChange={(e) => onInputChangeConfirmPassword(e)} />
                </div><br></br>
                <div className="btnsignup">
                    <button type="submit" class="btn btn-outline-secondary my-2 text-center mr-2">Sign Up</button>
                </div>
            </form>
        </div>
    </div>
  );
};

export default SignUp;