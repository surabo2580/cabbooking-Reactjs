import React from 'react';
  
const About = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'Center',
        alignItems: 'Center',
        height: '100vh'
      }}
    >
      <h1>About Go Anywhere.</h1>
    </div>
  );
};
  
export default About;