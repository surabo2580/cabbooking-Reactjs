import React from 'react';
  
const Contact = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'Center',
        alignItems: 'Center',
        height: '100vh'
      }}
    >
      <h1>Contact.</h1>
    </div>
  );
};
  
export default Contact;